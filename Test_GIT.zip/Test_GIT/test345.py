class A:
   def __init__(self,name):
      self.__name=name

if __name__=="__main__":
   a=A("test1")
   print(a._A__name)
   