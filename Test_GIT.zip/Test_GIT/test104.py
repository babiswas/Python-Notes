s="hello"
print("{} is the reversed value".format(s[-1::-1]))

