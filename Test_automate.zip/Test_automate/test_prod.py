from requests import get,post,patch,delete
from time import time
from time import sleep
import csv
from functools import wraps


EUSER={
  "data": {
    "type": "externalProfile",
    "attributes": {
      "allowedDomains": [
        "@yahoo.com",
        "@gmail.com"
      ],
      "expiry": "2029-05-14T18:29:59.000Z",
      "gamificationEnabled": false,
      "managerEmail": "m@m.com",
      "name": "EE",
      "paused": false,
      "seatLimit": 21,
      "verifyEmail": true
    }
  }
}




urls_get=[
  "https://captivateprime.adobe.com/primeapi/v2/badges?page[offset]=0&page[limit]=10&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/badges/477062",
  "https://captivateprime.adobe.com/primeapi/v2/users/3269469/userBadges?page[limit]=10&sort=dateAchieved",
  "https://captivateprime.adobe.com/primeapi/v2/users/3269469/userBadges/3269469_477064_CERTIFICATION_19404",
  "https://captivateprime.adobe.com/primeapi/v2/catalogs?page[offset]=0&page[limit]=10&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/catalogs/72511",
  "https://captivateprime.adobe.com/primeapi/v2/learningObjects?page[limit]=10&filter.loTypes=course&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/learningObjects?page[limit]=10&filter.loTypes=learningProgram&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/learningObjects?page[limit]=10&filter.loTypes=certification&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/userGroups?page[offset]=0&page[limit]=10&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/skills?page[offset]=0&page[limit]=10&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/skills/86636",
  "https://captivateprime.adobe.com/primeapi/v2/users/3269469/userSkills?page[offset]=0&page[limit]=10&sort=dateAchieved",
  "https://captivateprime.adobe.com/primeapi/v2/user",
  "https://captivateprime.adobe.com/primeapi/v2/users/3269469/userSkills?page[offset]=0&page[limit]=10&sort=dateAchieved",
  "https://captivateprime.adobe.com/primeapi/v2/users/3269469/userSkills/3269469_57578_1",
  "https://captivateprime.adobe.com/primeapi/v2/userGroups?page[offset]=0&page[limit]=10&sort=name",
  "https://captivateprime.adobe.com/primeapi/v2/userGroups/2834729",
  "https://captivateprime.adobe.com/primeapi/v2/externalProfiles?page[offset]=0&page[limit]=10",
  "https://captivateprime.adobe.com/primeapi/v2/externalProfiles/8557",
  "https://captivateprime.adobe.com/primeapi/v2/externalProfiles/8557/users?page[offset]=0&page[limit]=10",
  "https://captivateprime.adobe.com/primeapi/v2/externalProfiles/9427"
]

urls_post=[
   "https://captivateprime.adobe.com/primeapi/v2/externalProfiles",
   "https://captivateprime.adobe.com/primeapi/v2/users/3269469/enrollments?loId=course%3A1171772&loInstanceId=course%3A1171772_1260726"
]

urls_patch=[
  "https://captivateprime.adobe.com/primeapi/v2/externalProfiles/8557"
]


cred = {"client_id": "769e9ae8-ffc9-4477-b5f0-01acdbbc7b07",
        "client_secret": "d8d31b03-b19f-47ee-9664-844251e46a20","refresh_token":"086c2a8de0e73584e6ec3951bf48a030"}


#Generate Access Token
def get_New_Token(base_url,cred):
    header = {"Content-type":"application/x-www-form-urlencoded"}
    final_url =base_url+"oauth/token/refresh"
    try:
        response=post(final_url,params=cred,headers=header)
        data_json=response.json()
        return data_json
    except:
        print("Unable to generate the access token")
        pass
        return ""


# get request decorator
def get_request(func):
    global cred
    global l
    global data
    global base_url
    global token_url
    def wrapper(*args):
        url=base_url+str(args[0])
        Access_Token=get_New_Token(token_url,cred)
        hdr={"Authorization":"oauth "+Access_Token["access_token"]}
        print(url)
        print(data)
        res=get(url,params=data,headers=hdr)
        return func(args[0],res.json(),res.status_code)
    return wrapper


def post_request_payload(func):
    global cred
    global l
    global data
    global base_url
    global token_url
    @wraps(func)
    def wrapper(*args):
        str1=base_url+str(args[0])
        Access_Token = get_New_Token(token_url,cred)
        hdr = {"Authorization": "oauth " + str(Access_Token["access_token"]),"Content-type": "application/vnd.api+json","Accept": "application/vnd.api+json"}
        res = post(str1,params=data,headers=hdr,data=args[1])
        print(res)
        return func(args[0],args[1],res.json(),res.status_code)
    return wrapper

def patch_request_payload(func):
    global cred
    global l
    global data
    global base_url
    global token_url
    @wraps(func)
    def wrapper(*args):
        str1=base_url+str(args[0])
        Access_Token = get_New_Token(token_url,cred)
        hdr = {"Authorization": "oauth " + str(Access_Token["access_token"]),"Content-type": "application/vnd.api+json","Accept": "application/vnd.api+json"}
        res = patch(str1,params=data,headers=hdr,data=args[1])
        print("Showing patch data")
        print(res)
        return func(args[0],args[1],res.json(),res.status_code)
    return wrapper


if __name__=="__main__":






