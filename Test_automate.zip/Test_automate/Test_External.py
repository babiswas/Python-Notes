from utility import *
from time import time
import json
from functools import wraps
from time import sleep


ExternalUser={
   "data":{
      "type": "externalProfile",
      "attributes": {
        "allowedDomains": [
          "@gmail.com",
          "@adobe.com",
          "@yahoo.com",
          "@hcl.com"
        ],
        "enabled": False,
        "expiry": "2028-04-29T18:29:59.000Z",
        "gamificationEnabled": False,
        "loginRequired": 44,
        "managerEmail": "bapan@gg.com",
        "name": "FF",
        "seatLimit": 22,
        "verifyEmail": True
      }
    }
}


UpdateExternal={
  "data": {
    "id": "3017",
    "type": "externalProfile",
    "attributes": {
      "accessKey": "7ggandbl1i3pu",
      "allowedDomains": [
        "@gmail.com",
        "@adobe.com",
        "@yahoo.com",
        "@hcl.com"
      ],
      "enabled": False,
      "enrollmentCount": 0,
      "expiry": "2028-04-29T18:29:59.000Z",
      "gamificationEnabled": False,
      "loginRequired": 44,
      "managerEmail": "bapan1556362074.701367@gmail.com",
      "name": "FF",
      "paused": False,
      "seatLimit": 22,
      "url": "https://captivateprimestage1.adobe.com/eplogin?groupid=3017&accesskey=7ggandbl1i3pu",
      "verifyEmail": True
    }
  }
}


######################################################### JSON MODIFIER #########################################################################


def json_modifier():
    global ExternalUser
    ExternalUser["data"]["attributes"]["managerEmail"]="bapan"+str(time())+"@gmail.com"

#Update the email field of the user.
def json_modifier_eprofile_update_allowedDomain_add():
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["allowedDomains"].append("@infosys.com")

#Update the email field of the user.
def json_modifier_eprofile_update_allowedDomain_remove():
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["allowedDomains"].remove("@infosys.com")


#Update the json  field of the user.
def json_modifier_eprofile_update_expiry_date(datestr):
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["expiry"]=datestr+UpdateExternal["data"]["attributes"]["expiry"].split('-')[1]+UpdateExternal["data"]["attributes"]["expiry"].split('-')[2]


def json_modifier_eprofile_update_verifyemail(verifymail):
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["verifyEmail"]=verifymail


def json_modifier_eprofile_update_seatLimit(seatlimit):
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["seatLimit"]=seatlimit


def json_modifier_eprofile_update_loginrequireed(loginRequired):
  global UpdateExternal
  UpdateExternal["data"]["attributes"]["loginRequired"]=loginRequired


# def json_modifier_eprofile_update_name(name):
#   global UpdateExternal
#   UpdateExternal["data"]["attributes"]["name"]=name


######################################################################### REQUST METHODS ###########################################################


#POST request function for testing basic functionality of POST method
@post_request_payload
def post_External_user(*args):
      return args[2]

# #POST request function for getting the response body of the post method.
# @post_request_payload
# def post_get_user_body(*args):
#       return args[2]

#GET request function to retrieve the user by id.
@get_request
def get_External_user_by_id(*args):
    return args[1]

# @get_request
# def get_userbody_by_id(*args):
#     return args[1]

# #PATCH request to test the basic functionality of the PATCH method.
# @patch_request_payload
# def patch_update_user(*args):
#   return args[3]

#PATCH request function to test the PATCH api response body using GET.
@patch_request_payload
def patch_update_user_get_body(*args):
  return args[2]

# @delete_request_parameter
# def  delete_user_by_id(*args):
#     return args[1]


####################################################### TEST CASE ##############################################################


@Report_generate
def  test_create_External_user(Testcase):
     json_modifier()
     res=post_External_user("externalProfiles",json.dumps(ExternalUser))
     id=res["data"]["id"]
     str1="externalProfiles/"+str(id)
     res2=get_External_user_by_id(str1)
     print(res2)
     if res2["data"]["id"]==str(id):
     	return  True  
     else:
     	return False


@Report_generate
def  test_alloweddomainExternal_Profile_add(Testcase,id):
     json_modifier_eprofile_update_allowedDomain_add()
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if "@infosys.com" in res2["data"]["attributes"]["allowedDomains"]:
     	return  True  
     else:
     	return False


@Report_generate
def  test_alloweddomainExternal_Profile_remove(Testcase,id):
     json_modifier_eprofile_update_allowedDomain_remove()
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if "@infosys.com" not in res2["data"]["attributes"]["allowedDomains"]:
     	return  True  
     else:
     	return False


@Report_generate
def  test_External_Profile_verifymail_true(Testcase,id):
     json_modifier_eprofile_update_verifyemail(True)
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if res2["data"]["attributes"]["verifyEmail"]:
     	return  True  
     else:
     	return False

@Report_generate
def  test_External_Profile_verifymail_false(Testcase,id):
     json_modifier_eprofile_update_verifyemail(False)
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if not res2["data"]["attributes"]["verifyEmail"]:
     	return  True  
     else:
     	return False


@Report_generate
def  test_External_Profile_seatlimit(Testcase,id,seatlimit):
     json_modifier_eprofile_update_seatLimit(seatlimit)
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if res2["data"]["attributes"]["seatLimit"]==seatlimit:
     	return  True  
     else:
     	return False


@Report_generate
def  test_External_Profile_loginrequired(Testcase,id,loginrequired):
     json_modifier_eprofile_update_loginrequireed(loginrequired)
     str1="externalProfiles/"+str(id)
     res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
     res2=get_External_user_by_id(str1)
     print(res2)
     if res2["data"]["attributes"]["loginRequired"]==loginrequired:
     	return  True  
     else:
     	return False


# @Report_generate
# def  test_External_Profile_name(Testcase,id,name):
#      json_modifier_eprofile_update_name(name)
#      str1="externalProfiles/"+str(id)
#      res=patch_update_user_get_body(str1,json.dumps(UpdateExternal))
#      res2=get_External_user_by_id(str1)
#      print(res2)
#      if res2["data"]["attributes"]["name"]==name:
#      	return  True  
#      else:
#      	return False





if __name__=="__main__":
  	Auto_init("ExternalUser.csv")
  	test_create_External_user("Test the external user creation and verify using GET")
  	test_alloweddomainExternal_Profile_add("Test adding domains to the external profile @infosys.com",3017)
  	test_alloweddomainExternal_Profile_remove("Test removing domains to the external profile @infosys.com",3017)
  	test_External_Profile_verifymail_true("Test the external profile verify email update false state",3017)
  	test_External_Profile_verifymail_false("Test the external profile verify email update  true state",3017)
  	test_External_Profile_seatlimit("Test the external profile Update seat limit value 22",3017,22)
  	test_External_Profile_seatlimit("Test the external profile update seat limit value 23",3017,23)
  	test_External_Profile_loginrequired("Test the login required value update of the external profile with value set to 44",3017,44)
  	test_External_Profile_loginrequired("Test the login required value update of the external profile with value set to 45",3017,45)
  	# test_External_Profile_name("Test the name field update of the external profile name set to FF",id,"FF")
  	# test_External_Profile_name("Test the name field of update the external profile name set to FF",id,"GG")
  	Auto_close()

